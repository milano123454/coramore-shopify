/* CORAMORE v7 — theme.js */
(function() {
  'use strict';

  function initScrollReveal() {
    var els = document.querySelectorAll('.reveal-on-scroll');
    if (!els.length) return;
    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(e) {
        if (e.isIntersecting) {
          var d = parseInt(e.target.dataset.delay) || 0;
          setTimeout(function() { e.target.classList.add('is-visible'); }, d);
          observer.unobserve(e.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -30px 0px' });
    els.forEach(function(el, i) {
      var parent = el.parentElement;
      var siblings = parent ? parent.querySelectorAll(':scope > .reveal-on-scroll') : [];
      var idx = Array.prototype.indexOf.call(siblings, el);
      if (idx > 0) el.dataset.delay = idx * 60;
      observer.observe(el);
    });
  }

  function initStickyHeader() {
    var h = document.querySelector('.site-header--sticky');
    if (!h) return;
    window.addEventListener('scroll', function() {
      h.classList.toggle('site-header--scrolled', window.pageYOffset > 40);
    }, { passive: true });
  }

  function initMobileMenu() {
    var menu = document.querySelector('[data-mobile-menu]');
    if (!menu) return;
    document.querySelectorAll('[data-menu-toggle]').forEach(function(b) { b.addEventListener('click', function() { menu.classList.add('is-open'); document.body.style.overflow = 'hidden'; }); });
    document.querySelectorAll('[data-menu-close]').forEach(function(b) { b.addEventListener('click', function() { menu.classList.remove('is-open'); document.body.style.overflow = ''; }); });
  }

  function initFAQ() {
    document.querySelectorAll('[data-faq-toggle]').forEach(function(t) {
      t.addEventListener('click', function() {
        var ans = this.nextElementSibling;
        var open = this.getAttribute('aria-expanded') === 'true';
        var parent = this.closest('.faq-list, .product__details, .product__info');
        if (parent) parent.querySelectorAll('[data-faq-toggle]').forEach(function(o) {
          if (o !== t) { o.setAttribute('aria-expanded', 'false'); var a = o.nextElementSibling; if (a && a.hasAttribute('data-faq-answer')) a.style.maxHeight = null; }
        });
        this.setAttribute('aria-expanded', !open);
        if (ans && ans.hasAttribute('data-faq-answer')) {
          ans.style.maxHeight = open ? null : ans.scrollHeight + 'px';
        }
      });
    });
  }

  /* Countdown — session-based, configurable minutes */
  function initCountdown() {
    document.querySelectorAll('[data-countdown]').forEach(function(el) {
      var display = el.querySelector('[data-countdown-display]');
      if (!display) return;
      var minutes = parseInt(el.getAttribute('data-minutes')) || 15;
      var key = 'cm_cd_' + minutes;
      var endTime = sessionStorage.getItem(key);

      if (!endTime || parseInt(endTime) < Date.now()) {
        endTime = Date.now() + (minutes * 60 * 1000);
        sessionStorage.setItem(key, endTime);
      } else {
        endTime = parseInt(endTime);
      }

      function update() {
        var remaining = endTime - Date.now();
        if (remaining <= 0) {
          endTime = Date.now() + (minutes * 60 * 1000);
          sessionStorage.setItem(key, endTime);
          remaining = endTime - Date.now();
        }
        var m = Math.floor(remaining / 60000);
        var s = Math.floor((remaining % 60000) / 1000);
        display.textContent = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
      }
      update();
      setInterval(update, 1000);
    });
  }

  function initGallery() {
    var thumbs = document.querySelectorAll('[data-thumbnail]');
    var main = document.getElementById('product-main-image');
    if (!thumbs.length || !main) return;
    var firstThumb = thumbs[0];

    function goToThumb(t) {
  main.src = t.dataset.imageUrl;
  main.alt = t.dataset.imageAlt || '';
  thumbs.forEach(function(x) { x.classList.remove('product__thumbnail--active'); });
  t.classList.add('product__thumbnail--active');
  var badge = document.querySelector('.product__img-badge');
  if (badge) {
    badge.style.display = (t === firstThumb) ? '' : 'none';
  }
}

    thumbs.forEach(function(t) {
      t.addEventListener('click', function() { goToThumb(this); });
    });

    // Swipe touch sull'immagine principale
    var touchStartX = 0;
    var touchStartY = 0;
    var mainWrap = main.closest('.product__gallery-main') || main.parentElement;
    mainWrap.addEventListener('touchstart', function(e) {
      touchStartX = e.touches[0].clientX;
      touchStartY = e.touches[0].clientY;
    }, { passive: true });
    mainWrap.addEventListener('touchend', function(e) {
      var dx = e.changedTouches[0].clientX - touchStartX;
      var dy = e.changedTouches[0].clientY - touchStartY;
      // Solo se swipe orizzontale (dx > dy in valore assoluto) e almeno 40px
      if (Math.abs(dx) < 40 || Math.abs(dx) < Math.abs(dy)) return;
      var activeIndex = -1;
      thumbs.forEach(function(t, i) { if (t.classList.contains('product__thumbnail--active')) activeIndex = i; });
      if (activeIndex === -1) activeIndex = 0;
      var nextIndex;
      if (dx < 0) {
        // Swipe sinistra → immagine successiva
        nextIndex = activeIndex + 1 < thumbs.length ? activeIndex + 1 : 0;
      } else {
        // Swipe destra → immagine precedente
        nextIndex = activeIndex - 1 >= 0 ? activeIndex - 1 : thumbs.length - 1;
      }
      goToThumb(thumbs[nextIndex]);
    }, { passive: true });
  }

  function initQty() {
    // Product page quantity (data-qty-minus / data-qty-plus)
    document.querySelectorAll('[data-qty-minus]').forEach(function(b) {
      b.addEventListener('click', function() { var i = this.parentElement.querySelector('input'); var v = parseInt(i.value)||1; if (v > 1) i.value = v - 1; });
    });
    document.querySelectorAll('[data-qty-plus]').forEach(function(b) {
      b.addEventListener('click', function() { var i = this.parentElement.querySelector('input'); var v = parseInt(i.value)||1; if (v < 99) i.value = v + 1; });
    });
    // Cart page quantity (data-qty-update + data-action="plus/minus")
    document.querySelectorAll('[data-qty-update]').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var self = this;
        var action = self.getAttribute('data-action');
        var selector = self.closest('.quantity-selector');
        if (!selector) return;
        var input = selector.querySelector('input');
        if (!input) return;
        var v = parseInt(input.value) || 1;
        var newQty = v;
        if (action === 'minus' && v > 0) newQty = v - 1;
        if (action === 'plus' && v < 99) newQty = v + 1;
        input.value = newQty;

        var line = self.getAttribute('data-line');
        if (!line) return;

        // Disabilita i pulsanti durante l'aggiornamento
        var cartItem = self.closest('.cart-item');
        var allBtns = cartItem ? cartItem.querySelectorAll('[data-qty-update]') : [];
        allBtns.forEach(function(b) { b.disabled = true; });

        fetch('/cart/change.js', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ line: parseInt(line), quantity: newQty })
        })
        .then(function(r) { return r.json(); })
        .then(function(cart) {
          // Riabilita pulsanti
          allBtns.forEach(function(b) { b.disabled = false; });

          // Se quantità = 0, rimuovi la riga
          if (newQty === 0) {
            if (cartItem) cartItem.remove();
          } else {
            // Aggiorna il prezzo della singola riga
            var lineIdx = parseInt(line) - 1;
            if (cart.items && cart.items[lineIdx]) {
              var linePrice = cart.items[lineIdx].final_line_price;
              var linePriceEl = cartItem ? cartItem.querySelector('.cart-item__line-price') : null;
              if (linePriceEl && linePrice !== undefined) {
                linePriceEl.textContent = '\u20ac' + (linePrice / 100).toFixed(2).replace('.', ',');
              }
            }
          }

          // Aggiorna subtotale e totale nella sidebar
          var money = function(cents) {
            return '\u20ac' + (cents / 100).toFixed(2).replace('.', ',');
          };
          var summaryRows = document.querySelectorAll('.cart__summary-row span:last-child');
          // Row 0 = subtotale, Row last-1 = totale (struttura fissa del template)
          var subtotalEl = document.querySelector('.cart__summary-row:first-child span:last-child');
          var totalEl = document.querySelector('.cart__summary-row--total span:last-child');
          if (subtotalEl && cart.total_price !== undefined) subtotalEl.textContent = money(cart.total_price);
          if (totalEl && cart.total_price !== undefined) totalEl.textContent = money(cart.total_price);
        })
        .catch(function(err) {
          allBtns.forEach(function(b) { b.disabled = false; });
          console.error('Cart update error:', err);
        });
      });
    });
  }

  function initCarousels() {
    document.querySelectorAll('[data-video-track]').forEach(function(track) {
      var w = track.closest('.video-reviews__wrapper'); if (!w) return;
      var l = w.querySelector('[data-scroll-left]'), r = w.querySelector('[data-scroll-right]');
      if (l) l.addEventListener('click', function() {
        var card = track.querySelector('.video-review-card');
        var amount = card ? card.offsetWidth + 14 : 234;
        track.scrollBy({left:-amount,behavior:'smooth'});
      });
      if (r) r.addEventListener('click', function() {
        var card = track.querySelector('.video-review-card');
        var amount = card ? card.offsetWidth + 14 : 234;
        track.scrollBy({left:amount,behavior:'smooth'});
      });
    });
    document.querySelectorAll('[data-reviews-track]').forEach(function(track) {
      var w = track.closest('.reviews-carousel'); if (!w) return;
      var l = w.querySelector('[data-reviews-scroll-left]'), r = w.querySelector('[data-reviews-scroll-right]');
      if (l) l.addEventListener('click', function() { track.scrollBy({left:-320,behavior:'smooth'}); });
      if (r) r.addEventListener('click', function() { track.scrollBy({left:320,behavior:'smooth'}); });
    });
  }

  /* Video play/pause with custom button */
  function initVideoPlayers() {
    function setSharpPoster(video) {
      var doSeek = function() { video.currentTime = 0.1; };
      if (video.readyState >= 1) { doSeek(); }
      else { video.addEventListener('loadedmetadata', doSeek, {once: true}); }
      video.addEventListener('seeked', function onSeeked() {
        video.removeEventListener('seeked', onSeeked);
        try {
          var canvas = document.createElement('canvas');
          canvas.width = video.videoWidth || 220;
          canvas.height = video.videoHeight || 390;
          canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
          var dataUrl = canvas.toDataURL('image/jpeg', 0.92);
          if (dataUrl.length > 5000) video.setAttribute('poster', dataUrl);
        } catch(e) {}
        video.currentTime = 0;
      });
    }

    document.querySelectorAll('[data-video-el]').forEach(function(video) {
      setSharpPoster(video);
    });

    function playVideo(video, wrap) {
      document.querySelectorAll('[data-video-wrap] video').forEach(function(v) {
        if (v !== video) {
          v.pause(); v.currentTime = 0;
          var w = v.closest('[data-video-wrap]');
          if (w) w.classList.remove('is-playing');
        }
      });
      video.muted = true;
      var p = video.play();
      if (p !== undefined) {
        p.then(function() {
          wrap.classList.add('is-playing');
          try { video.muted = false; } catch(e) {}
        }).catch(function() { wrap.classList.remove('is-playing'); });
      } else {
        wrap.classList.add('is-playing');
      }
    }

    document.querySelectorAll('[data-play-btn]').forEach(function(btn) {
      btn.addEventListener('touchend', function(e) {
        e.preventDefault(); e.stopPropagation();
        var wrap = this.closest('[data-video-wrap]');
        if (!wrap) return;
        var video = wrap.querySelector('video');
        if (!video) return;
        if (wrap.classList.contains('is-playing')) {
          video.pause(); wrap.classList.remove('is-playing');
        } else { playVideo(video, wrap); }
      });
      btn.addEventListener('click', function(e) {
        e.preventDefault(); e.stopPropagation();
        var wrap = this.closest('[data-video-wrap]');
        if (!wrap) return;
        var video = wrap.querySelector('video');
        if (!video) return;
        if (wrap.classList.contains('is-playing')) {
          video.pause(); wrap.classList.remove('is-playing');
        } else {
          playVideo(video, wrap);
        }
      });
    });

    // Aggiungo overlay trasparente su ogni video-wrap per catturare tap/click su mobile
    document.querySelectorAll('[data-video-wrap]').forEach(function(wrap) {
      var overlay = document.createElement('div');
      overlay.setAttribute('data-video-overlay', '');
      overlay.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;z-index:2;cursor:pointer;-webkit-tap-highlight-color:transparent;';
      wrap.appendChild(overlay);

      function toggleVideo() {
        var video = wrap.querySelector('video');
        if (!video) return;
        if (wrap.classList.contains('is-playing')) {
          video.pause();
          wrap.classList.remove('is-playing');
        } else {
          playVideo(video, wrap);
        }
      }

      overlay.addEventListener('touchend', function(e) {
        // Ignora se si tratta di uno swipe (movimento > 10px)
        e.preventDefault();
        toggleVideo();
      });
      overlay.addEventListener('click', function(e) {
        e.preventDefault();
        toggleVideo();
      });
    });

    // Ended: rimostra play button, torna a inizio
    document.querySelectorAll('[data-video-wrap] video').forEach(function(video) {
      video.addEventListener('ended', function() {
        var wrap = video.closest('[data-video-wrap]');
        if (wrap) wrap.classList.remove('is-playing');
        video.currentTime = 0;
      });
    });
  }

  function initVariants() {
    var mainImg = document.getElementById('product-main-image');
    var variantInput = document.querySelector('#product-form input[name="id"]');
    var thumbs = document.querySelectorAll('[data-thumbnail]');

    document.querySelectorAll('.product__swatch').forEach(function(s) {
      s.addEventListener('click', function() {
        var optionValues = this.closest('.product__option-values');
        var optionBlock  = this.closest('.product__option');

        // Aggiorna stato attivo dentro il gruppo
        optionValues.querySelectorAll('.product__swatch').forEach(function(x) { x.classList.remove('product__swatch--active'); });
        this.classList.add('product__swatch--active');

        // Aggiorna il nome colore selezionato nella label (es. "Colore — Rosa")
        if (optionBlock) {
          var selectedNameEl = optionBlock.querySelector('.product__option-selected-name');
          if (selectedNameEl) {
            selectedNameEl.textContent = '\u00a0\u2014 ' + (this.dataset.value || this.title || '');
          }
        }

        // Aggiorna variant ID nel form
        var vid = this.dataset.variantId;
        if (vid && variantInput) {
          variantInput.value = vid;
        }

        // Aggiorna immagine principale
        var imageUrl = this.dataset.imageUrl;
        if (imageUrl && mainImg) {
          mainImg.src = imageUrl;
          var swatchImg = this.querySelector('img');
          mainImg.alt = swatchImg ? (swatchImg.alt || '') : '';

          // Evidenzia la thumbnail corrispondente
          var firstThumbUrl = thumbs.length ? thumbs[0].dataset.imageUrl : null;
          thumbs.forEach(function(t) {
            t.classList.remove('product__thumbnail--active');
            if (t.dataset.imageUrl === imageUrl) {
              t.classList.add('product__thumbnail--active');
            }
          });

          // Mostra il banner solo sulla prima immagine
          var badge = document.querySelector('.product__img-badge');
          if (badge) {
            badge.style.display = (imageUrl === firstThumbUrl) ? '' : 'none';
          }
        }
      });
    });
  }

  function initCouponRestore() {
    // Dopo la redirect Shopify /discount/CODE?redirect=..., il codice è in sessione.
    // Ripristiniamo lo stato visivo del pulsante e del prezzo.
    var appliedCode, appliedPct;
    try {
      appliedCode = sessionStorage.getItem('coupon_applied');
      appliedPct = parseInt(sessionStorage.getItem('coupon_pct') || '20');
    } catch(e) {}

    if (!appliedCode) return;

    // --- PRODUCT PAGE ---
    // Aggiorna pulsante coupon sulla product page
    var btn = document.getElementById('apply-coupon-btn');
    if (btn && btn.getAttribute('data-code') === appliedCode) {
      btn.textContent = '\u2713 Applicato!';
      btn.classList.add('applied');
    }

    // Aggiorna prezzo visivamente SOLO se l'utente ha cliccato "Applica" (flag coupon_price_updated)
    var priceUpdateAllowed = false;
    try { priceUpdateAllowed = sessionStorage.getItem('coupon_price_updated') === '1'; } catch(e) {}
    var saleEl = document.querySelector('.product__price-sale');
    if (priceUpdateAllowed && saleEl && !saleEl.getAttribute('data-coupon-applied')) {
      saleEl.setAttribute('data-coupon-applied', '1');
      var rawText = saleEl.textContent.replace(/[^\d,\.]/g, '').replace(',', '.');
      var currentPrice = parseFloat(rawText);
      if (!isNaN(currentPrice) && appliedPct > 0) {
        var newPrice = currentPrice * (1 - appliedPct / 100);
        var formatted = '\u20ac' + newPrice.toFixed(2).replace('.', ',');
        var wasEl = document.querySelector('.product__price-was');
        if (!wasEl) {
          var newWas = document.createElement('span');
          newWas.className = 'product__price-was';
          newWas.style.cssText = 'text-decoration:line-through;color:#999;font-size:13px;margin-left:6px;';
          newWas.textContent = saleEl.textContent;
          saleEl.parentNode.insertBefore(newWas, saleEl.nextSibling);
        }
        saleEl.textContent = formatted;
        var badgeEl = document.querySelector('.product__price-badge');
        if (badgeEl) badgeEl.textContent = '-' + appliedPct + '%';
      }
    }

    // --- CART PAGE ---
    // Aggiorna pulsante coupon sul carrello
    var cartBtn = document.getElementById('cart-apply-coupon');
    if (cartBtn && cartBtn.getAttribute('data-code') === appliedCode) {
      cartBtn.textContent = '\u2713 Applicato!';
      cartBtn.classList.add('applied');
      cartBtn.disabled = true;
    }

    // Shopify ha già applicato lo sconto reale sui prezzi nel carrello (final_line_price).
    // NON ricalcoliamo nulla — mostriamo solo i prezzi reali di Shopify.
    // Nascondiamo solo la riga "sconto" nel riepilogo per evitare confusione visiva.
    var discountRow = document.querySelector('.cart__summary-row--discount');
    if (discountRow) {
      discountRow.style.display = 'none';
    }
    // Nascondiamo anche il prezzo barrato accanto al prezzo originale per ogni riga
    document.querySelectorAll('.cart-item__original-price').forEach(function(el) {
      el.style.display = 'none';
    });
  }

  function init() {
    initScrollReveal(); initStickyHeader(); initMobileMenu(); initFAQ();
    initCountdown(); initGallery(); initQty(); initCarousels();
    initVideoPlayers(); initVariants(); initCouponRestore();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

  // Fix editor Shopify: quando si modifica una sezione, i reveal-on-scroll
  // restano opacity:0 finché non si salva. Qui li rendiamo subito visibili.
  document.addEventListener('shopify:section:load', function(e) {
    var section = e.target;
    // Rendi visibili tutti gli elementi animated nella sezione aggiornata
    section.querySelectorAll('.reveal-on-scroll').forEach(function(el) {
      el.classList.add('is-visible');
    });
    // Re-inizializza le funzionalità interattive nella sezione
    initGallery();
    initFAQ();
    initCountdown();
    initCarousels();
    initVideoPlayers();
    initVariants();
    initScrollReveal();
  });

  // Quando si entra in modalità editor, mostra subito tutti gli elementi
  document.addEventListener('shopify:preview_theme:focus', function() {
    document.querySelectorAll('.reveal-on-scroll').forEach(function(el) {
      el.classList.add('is-visible');
    });
  });
})();

/* ============================================
   COUPON APPLICABILE CON UN CLICK
   - Registra il codice in sessione Shopify via iframe
   - Aggiorna il prezzo visivamente sulla product page
   ============================================ */
function applyCoupon(btn) {
  var code = btn.getAttribute('data-code');
  if (!code) return;

  // Calcola percentuale di sconto dal testo (per aggiornamento visivo)
  var discPct = 20;
  var couponBox = btn.closest('.product__coupon');
  if (couponBox) {
    var textEl = couponBox.querySelector('.product__coupon-text');
    if (textEl) {
      var match = textEl.textContent.match(/(\d+)\s*%/);
      if (match) discPct = parseInt(match[1]);
    }
  }

  // Salva lo stato del coupon in sessionStorage PRIMA della navigazione
  // così quando l'utente torna sulla pagina sappiamo che il coupon era già applicato
  try {
    sessionStorage.setItem('coupon_applied', code);
    sessionStorage.setItem('coupon_pct', String(discPct));
    sessionStorage.setItem('coupon_price_updated', '1');
  } catch(e) {}

  // Redirect REALE a Shopify discount URL — questo è l'unico modo affidabile
  // per registrare il codice nella sessione Shopify (cookie HttpOnly).
  // L'iframe viene bloccato dai browser moderni per i cookie di sessione.
  // Shopify applica il codice e riporta l'utente sulla pagina corrente.
  var returnUrl = window.location.pathname + window.location.search + '#apply-coupon-btn';
  window.location.href = '/discount/' + encodeURIComponent(code) + '?redirect=' + encodeURIComponent(returnUrl);
}

function applyCartCoupon(btn) {
  var code = btn.getAttribute('data-code');
  if (!code) return;
  try { sessionStorage.setItem('coupon_applied', code); } catch(e) {}
  var returnUrl = window.location.pathname + window.location.search;
  window.location.href = '/discount/' + encodeURIComponent(code) + '?redirect=' + encodeURIComponent(returnUrl);
}

function buyNowClick(btn) {
  var form = document.getElementById('product-form');
  if (!form) { window.location.href = '/checkout'; return; }

  var variantId = form.querySelector('input[name="id"]');
  var qty = form.querySelector('input[name="quantity"]');
  if (!variantId || !variantId.value) { window.location.href = '/checkout'; return; }

  var originalText = btn.textContent;
  btn.disabled = true;
  btn.textContent = '...';

  var quantity = qty ? parseInt(qty.value) || 1 : 1;

  // Prima svuota il carrello, poi aggiunge solo la variante selezionata.
  // Questo evita l'accumulo quando l'utente torna indietro dal checkout e riclicca.
  fetch('/cart/clear.js', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  })
  .then(function() {
    return fetch('/cart/add.js', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: parseInt(variantId.value),
        quantity: quantity
      })
    });
  })
  .then(function() {
    // Recupera il codice sconto applicato via URL o sessionStorage
    var discountCode = null;
    var urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('discount')) {
      discountCode = urlParams.get('discount');
    } else {
      try { discountCode = sessionStorage.getItem('coupon_applied'); } catch(e) {}
    }
    if (discountCode) {
      window.location.href = '/checkout?discount=' + encodeURIComponent(discountCode);
    } else {
      window.location.href = '/checkout';
    }
  })
  .catch(function() {
    btn.disabled = false;
    btn.textContent = originalText;
  });
}

// Ripristina il pulsante "A quest'ora" se l'utente torna indietro dal checkout (bfcache)
window.addEventListener('pageshow', function(e) {
  if (e.persisted) {
    var buyNowBtn = document.querySelector('.product__buy-now');
    if (buyNowBtn) {
      buyNowBtn.disabled = false;
      // Ripristina il testo originale dall'attributo data- se disponibile,
      // altrimenti ricarica la pagina per forzare il re-render del liquid
      var saved = buyNowBtn.getAttribute('data-original-text');
      if (saved) {
        buyNowBtn.textContent = saved;
      } else {
        window.location.reload();
      }
    }
  }
});





/* ============================================
   TIMER SPEDIZIONE INTELLIGENTE
   - Usa il fuso orario Europe/Rome (Italia, Spagna, Francia, ecc.)
   - 00:00 → 15:59 → consegna domani
   - 16:00 → 23:59 → consegna dopodomani
   - Timer per sessione: minuti e secondi dispari casuali (sembra già in corso)
   ============================================ */
(function() {
  var timerEl = document.getElementById('shipping-timer-text');
  if (!timerEl) return;

  var GIORNI = ['domenica','lunedì','martedì','mercoledì','giovedì','venerdì','sabato'];
  var MESI = ['gennaio','febbraio','marzo','aprile','maggio','giugno','luglio','agosto','settembre','ottobre','novembre','dicembre'];

  function getNowRome() {
    var parts = new Intl.DateTimeFormat('it-IT', {
      timeZone: 'Europe/Rome',
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
      hour12: false
    }).formatToParts(new Date());
    var p = {};
    parts.forEach(function(x) { p[x.type] = parseInt(x.value, 10); });
    return {
      hour: p.hour,
      minute: p.minute,
      second: p.second,
      date: new Date(p.year, p.month - 1, p.day)
    };
  }

  function formatData(date, offsetDays) {
    var d = new Date(date);
    d.setDate(d.getDate() + offsetDays);
    if (d.getDay() === 0) d.setDate(d.getDate() + 1);
    return GIORNI[d.getDay()] + ' ' + d.getDate() + ' ' + MESI[d.getMonth()];
  }

  function pad(n) { return n < 10 ? '0' + n : n; }

  // Genera un numero dispari casuale tra min e max (inclusi)
  function randomOdd(min, max) {
    var n = min + Math.floor(Math.random() * (max - min + 1));
    if (n % 2 === 0) n = n + 1 > max ? n - 1 : n + 1;
    return n;
  }

  // Calcola il tempo iniziale della sessione (dispari su minuti e secondi)
  // Salvato in sessionStorage così non cambia se la pagina viene refreshata
  var SESSION_KEY = 'cm_ship_end';
  var endTime = sessionStorage.getItem(SESSION_KEY);
  if (!endTime || parseInt(endTime) < Date.now()) {
    var initMinutes = randomOdd(7, 9); // tra 7 e 9 minuti, dispari
    var initSeconds = randomOdd(11, 57); // secondi dispari casuali
    var totalInitMs = (initMinutes * 60 + initSeconds) * 1000;
    endTime = Date.now() + totalInitMs;
    sessionStorage.setItem(SESSION_KEY, endTime);
  } else {
    endTime = parseInt(endTime);
  }

  function tick() {
    var now = getNowRome();
    var h = now.hour;
    var dataConsegna = formatData(now.date, h < 16 ? 1 : 2);

    var remaining = endTime - Date.now();

    if (remaining > 0) {
      var rm = Math.floor(remaining / 60000);
      var rs = Math.floor((remaining % 60000) / 1000);
      timerEl.innerHTML = 'Ordina entro <strong style="color:#D94040;">' +
        pad(rm) + ':' + pad(rs) +
        '</strong> e ricevi <strong>' + dataConsegna + '</strong>';
    } else {
      timerEl.innerHTML = 'Ordina subito e ricevi <strong>' + dataConsegna + '</strong>';
    }

    requestAnimationFrame(function() {
      setTimeout(tick, 1000);
    });
  }

  tick();
})();
